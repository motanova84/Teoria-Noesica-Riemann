# Simulated content of noesis88/start_noesis.sh
# Actual content will be inserted in deployment phase