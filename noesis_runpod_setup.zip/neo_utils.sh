# Simulated content of root/neo_utils.sh
# Actual content will be inserted in deployment phase