# Simulated content of root/ecosystem.config.js
# Actual content will be inserted in deployment phase