# Simulated content of root/watch_and_upload.sh
# Actual content will be inserted in deployment phase